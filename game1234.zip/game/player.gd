extends CharacterBody2D

var Tulip_count = 0
func _physics_process(delta):
	var input_direction = Input.get_vector("ui_left","ui_right","ui_up","ui_down")
	velocity = input_direction * 400
	move_and_slide()


func _on_pickup_area_area_entered(area):
	if area.is_in_group("Tulip") and not $HeldTulip.visible:
		area.queue_free()
		$HeldTulip.visible = true
		
	if area.is_in_group("Basket") and $HeldTulip.visible:
		$HeldTulip.visible = false
		Tulip_count += 1
		$CanvasLayer/TulipCountDisplay.text = "Tulips: " + str(Tulip_count)
